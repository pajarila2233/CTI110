name = input(' Enter name ')
print(f' Hello {name} and welcome to CS Online!')




